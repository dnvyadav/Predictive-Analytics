set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
set mapreduce.job.reduces=3000;
set hive.exec.max.dynamic.partitions=50000;

create database if not exists likely;
use likely;

drop table if exists date_diff;
create table date_diff as
select date_sub(current_date,30) as start_dt, current_date as end_dt;

drop table if exist date_dim;
create table date_dim as
select date_add(a.start_dt,pe.i) as alldate
from date_diff as a
lateral view posexplode(split(space(datediff(a.end_dt,a.start_dt)),'')) pe as i,x;

create external table likely.mls_training_tmp (
likely_id	int,
cc_property_id	int,
cc_record_id	double,
cc_list_id	int,
attom_id	int,
record_date_time	String,
customer_tracking_id	int,
cc_property_address_display_1	String,
cc_property_address_number	int,
cc_property_address_dir_prefix	String,
cc_property_address_street_name	String,
cc_property_address_street_suffix	String,
cc_property_address_dir_suffix	String,
cc_property_address_unit_type	String,
cc_property_address_unit_number	String,
cc_property_address_display_2	String,
cc_property_address_city	String,
cc_property_address_state	String,
cc_property_address_postal_code	int,
cc_property_address_postal_code_plus_4	int,
cc_property_address_county	String,
address	String,
city	String,
state_	String,
zip	int,
fips_county_cd	int,
most_recent_sale	String,
most_recent_sale_date	int,
trended_prior_sale	int,
market_ppsf	int,
broker	String,
mls_name	String,
status	String,
date_	String,
apn	String )
row format delimited fields terminated by '\t' collection items terminated by ':' lines terminated by '\n'
LOCATION '/ai/likely/platform/dev/data/mls_training/';

drop table if exists mls_training_1;
create table mls_training_1 row format delimited fields terminated by ',' collection items terminated by ':' lines terminated by '\n' as 
select 
likely_id,
cc_property_id,
cc_record_id,
cc_list_id,
attom_id,
record_date_time,
customer_tracking_id,
cc_property_address_display_1
,cc_property_address_number
,nvl(cc_property_address_dir_prefix,"NULL")
,nvl(cc_property_address_street_name,"NULL")
,nvl(cc_property_address_street_suffix,"NULL")
,nvl(cc_property_address_dir_suffix,"NULL")
,nvl(cc_property_address_unit_type,"NULL")
,nvl(cc_property_address_unit_number,"NULL")
,nvl(cc_property_address_postal_code,0)
,nvl(cc_property_address_postal_code_plus_4,"NULL")
,nvl(cc_property_address_county,"NULL")
,nvl(state_,"NULL")
,nvl(zip,"NULL")
,nvl(fips_county_cd,"NULL")
,nvl(most_recent_sale,"NULL")
,nvl(most_recent_sale_date,"NULL")
,nvl(trended_prior_sale,"NULL")
,nvl(market_ppsf,"NULL")
,nvl(broker,"NULL")
,nvl(mls_name,"NULL")
,nvl(status,"NULL")
,nvl(date_,"NULL")
,nvl(apn,"NULL")
from likely.mls_training_tmp
where record_date_time in not null and record_date_time between date_sub(current_date,30) and current_date;





